// generated from rosidl_generator_c/resource/idl.h.em
// with input from nav_msgs:msg/MapMetaData.idl
// generated code does not contain a copyright notice

#ifndef NAV_MSGS__MSG__MAP_META_DATA_H_
#define NAV_MSGS__MSG__MAP_META_DATA_H_

#include "nav_msgs/msg/detail/map_meta_data__struct.h"
#include "nav_msgs/msg/detail/map_meta_data__functions.h"
#include "nav_msgs/msg/detail/map_meta_data__type_support.h"

#endif  // NAV_MSGS__MSG__MAP_META_DATA_H_
